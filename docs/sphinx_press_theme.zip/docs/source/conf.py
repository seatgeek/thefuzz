
import os
import sys

# Add the root directory to the path so sphinx can find the modules
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
sys.path.insert(0, root_dir)

# Add any parent package directory if it exists
parent_dir = os.path.abspath(os.path.join(root_dir, '..'))
if os.path.exists(parent_dir):
    sys.path.insert(0, parent_dir)

project = 'Fuzzy String Matching'
copyright = '2024'
author = 'Author'
release = '0.22.1'

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.napoleon',
    'sphinx.ext.viewcode'
]

# Configure autodoc to handle relative imports
autodoc_mock_imports = ['rapidfuzz']

templates_path = ['_templates']
exclude_patterns = []

html_theme = 'press'
